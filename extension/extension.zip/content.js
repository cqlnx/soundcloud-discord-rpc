function getElapsedSeconds() {
    const el = document.querySelector(".playbackTimeline__timePassed span");
    if (!el) return 0;

    const parts = el.textContent.split(":").map(Number);

    if (parts.length === 2) {
        return parts[0] * 60 + parts[1];
    }
    if (parts.length === 3) {
        return parts[0] * 3600 + parts[1] * 60 + parts[2];
    }

    return 0;
}

function getTrackData() {
    const title = document.querySelector(".playbackSoundBadge__titleLink span")?.textContent;
    const artist = document.querySelector(".playbackSoundBadge__lightLink")?.textContent;

    if (!title) return null;

    return {
        title,
        artist,
        elapsed: getElapsedSeconds()
    };
}

async function sendUpdate() {
    const data = getTrackData();
    if (!data) return;

    fetch("http://localhost:8765/update", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    }).catch(() => {});
}

setInterval(sendUpdate, 5000);
